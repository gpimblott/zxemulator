## Use of ZX Spectrum BASIC ROM

The ZX Spectrum ROM is included with this project on the understanding that this is permittted by Amstrad who are the owners of the copyright.  See the included Readme.txt for the original message from Amstrad allowing distribution.

The rest of the project emulator developed by me is published under the MIT license.

## Diagnostics ROM

I have included the diagnostics ROM from Brendan Alford's ZX Diagnostics project.  This is Distributed under the GNU General Public License v3.0 license.

More information can be found on his site:
ß
https://github.com/brendanalford/zx-diagnostics

